'use strict'

const fs = require('fs');
const path = require('path');
let sampleData = './teradata.json';
let obj = JSON.parse(fs.readFileSync(__dirname+'/teradata.json','utf8'));
let recordsetNames = getRecordsetNames(obj)


// if user passed in names, just show names
// otherwise, show the data
if (process.argv[2] === 'names') {
	console.log('Recordset Names', recordsetNames)
} else {
	let recordsetToShow = process.argv[2]
	recordsetNames.forEach(function(name,idx) {
		if (recordsetToShow !== undefined && recordsetToShow !== name)
			return
		console.log('******* ' + name + ' *******')
		console.log(obj[idx][name].slice(0))
	})
}

function getRecordsetNames(obj) {
	 return obj.reduce((prev,cur) => {
		let recordsetName = Object.keys(cur)[0]
		prev.push(recordsetName)
		return prev
	},[])
}






//var Lambda = require('./Lambda');

//Overview insert.
var Database = function(id,key,region)
{
	this.accessKeyId	 =  id;
	this.secretAccessKey =  key;
	this.region          =  region;

}

Database.prototype.insert = function(queryType, data, dbType, itemdate, cb)
{

	if(!queryType || !data || !dbType) throw 'queryType, data, or dbType is missing!';
	DynamoDB = require('aws-dynamodb')(this.accessKeyId,this.secretAccessKey,this.region);	
	DynamoDB
			.table(dbType)
			.insert_or_replace({
//			.insert({
			query_type : queryType,
			date : itemdate,
//			date : new Date().getTime(),
			data : data

			},function(err,data){
				if(err)
				{
					console.log('Err inserting record ',err);
					return cb(err, undefined);
				}
				else
				{
					return cb(undefined,data);			
				}
			});
}

module.exports = Database;
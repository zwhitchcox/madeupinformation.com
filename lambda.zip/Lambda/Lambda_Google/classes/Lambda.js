//Helper lambda function for parsing teradata and google analytics;
'use strict'
var _ = require('underscore');
var moment = require('moment');
var  fs = require('fs');
//set local day
moment.locale('en', {
    weekdays : [
        "S", "M", "T", "W", "TH", "F", "S"
    ]
});
var Lamda = function(json)
{


}

/*************************Start Users************************************/

Lamda.prototype.topCampaigns = function(campaigns) {
	// body...
   return formatCampaigns(campaigns);

};

Lamda.prototype.locations = function(locations)
{
	return formatLocation(locations)
}
Lamda.prototype.dailyUserCount = function(usersByDevice)
{
	return formatDailyUserCount(usersByDevice);
}


Lamda.prototype.usersByLocation = function(userLocations)
{
	return formatUsersByLocation(userLocations);
}
function formatCampaigns(campaigns)
{
	var campaign_objects = _.unzip(campaigns);
	console.log(campaigns[0][0],campaigns[0][1]);


	var unique_keys = [];
	var unique_values = [];
	campaigns.forEach(function(campaign){
		//console.log(campaign);
		var full_name = campaign[0];
		var value = campaign[1];
		
		var last_part_array = full_name.split('/');

		var last_part = last_part_array[last_part_array.length - 1];
		//console.log(last_part);
		if(last_part != 'nutrition')
		{

		
			if(unique_keys.indexOf(last_part) >= 0 )
			{
					//key arleady exist
					//console.log('key already exist ',last_part);
					var i = unique_keys.indexOf(last_part);
					//console.log('count currnet count is  ',unique_keys[i + 1]);
					var old_value = unique_values[i];
					//console.log('old value ' ,old_value);
					unique_values[i] = parseInt(old_value) + parseInt(value);
					//console.log('new count is ',unique_keys[i + 1]);

			}
			else
			{
					//push key then value
					unique_keys.push(last_part);
					unique_values.push(value);
			}
		}

	});
	//lets compact to object
		//we need to grabe 
		//var unique_keys_to_object = _.object(unique_keys);
		var collection = [];
		for(var i = 0 ; i < unique_keys.length; i++)
		{
			var tmp = {};
			tmp.name = unique_keys[i];
			tmp.value = unique_values[i];
			collection.push(tmp);
		}
	   fs.writeFile(__dirname + 'output.txt',JSON.stringify(collection),function(err){
         if(err) console.log('err writing file ',err);
       })
        
       return collection;

}
function formatLocation(locations)
{
	//console.log(locations);

	var auto = locations[0];
	var man = locations[1];
	var struct = [];
	//count is last item in array
	var auto_obj = {
		count : parseInt(auto[auto.length - 1]),
		name : "Nearest Location"
	};
	var man_obj = {
		count : parseInt(man[man.length - 1]),
		name  : "Manual Address"
	};
	struct.push(auto_obj);
	struct.push(man_obj);
	return struct;
}
function formatDailyUserCount(users)
{
	var formatted = [];
	//lets partion our array
	var androidUsers = [];
	var iosUsers = [];
	users.forEach(function(user){
		if(user[0] ==='Android')
		{
			//lets get our label date
			androidUsers.push(user)
		}
		else
		{
			iosUsers.push(user);
		}
	});

	//lets formate our collection
	var count = 0;
	iosUsers.forEach(function(iosUser){
		//get day of week
		var day =   moment(iosUser,'YYYY-MM-DD').day();
		var d =  moment.weekdays(day);
		var tmp = {
			label : d,
			count : {
				"ios" : parseInt(iosUser[2]),
				"android" : parseInt(androidUsers[count][2]) 
			}
		}
		formatted.push(tmp);
		count++;
	});

	return formatted;
}

function formatUsersByLocation(usersByLocation)
{
	//console.log('users by location ',usersByLocation[0][0]);
	var formatted = [];
	usersByLocation.forEach(function(location){
		var lon = parseFloat(location[2]);
		var lat = parseFloat(location[1]);
		
		// JTATUM - strip out invalid lat/lon because it causes
		// map not to plot!
		if (lon != 0 && lat != 0)
		{
			// strip out lon/lat that are not in the d3.geo.albersUsa map 
			// because they cause the projection to return null.
			//if (lat < 20 || lat > 50 || lon > -70 || lon < -123)
			//{
				// don't add these!  They probably are not in the USA!
			//}
			//else
			//{			
				var tmp = {
					"longitude" : parseFloat(lon),
					"latitude" : parseFloat(lat),
					"value"     : parseInt(location[3])

				}
				if(formatted.length <= 1000)
				{
					formatted.push(tmp);
				}
			//}
		}
	
	});
	//var test = []
	//test.push(formatted[0]);
	//test.push(formatted[1]);
	//console.log(formatted);
	/*var test = [
	{
		"longitude": -118,
		"latitude": 33,
		"value": 40
	},
	{
		"longitude": -122,
		"latitude": 37,
		"value": 30
	},
	{
		"longitude": -81,
		"latitude": 32,
		"value": 5
	},
	{
		"longitude": -84,
		"latitude": 33,
		"value": 2
	},
	{
		"longitude": -90,
		"latitude": 38,
		"value": 12
	},
	{
		"longitude": -87.6,
		"latitude": 41.8,
		"value": 20
	},
	{
		"longitude": -87.9,
		"latitude": 43,
		"value": 8
	},
	{
		"longitude": -83,
		"latitude": 42.3,
		"value": 11
	},
	{
		"longitude": -74,
		"latitude": 40,
		"value": 45
	}
] */
	return formatted;
}
/*************************End Users**************************************/
module.exports = Lamda;
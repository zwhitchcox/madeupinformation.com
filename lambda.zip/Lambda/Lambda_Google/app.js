 exports.ga = function(event,context){
    var fs = require('fs'),
        crypto = require('crypto'),
        request = require('request'); // This is an external module (https://github.com/mikeal/request)
        _       = require('underscore');
        Lambda  = require('./classes/Lambda');
        Database = require('./classes/Database');
        moment   = require('moment');

var db = new Database('AKIAIES7HWWZXH5XUKCQ','OiIOepShMFwuDuwiAoRvMWKWFCDK9sR88y2','us-east-1');
    var authHeader = {
            'alg': 'RS256',
            'typ': 'JWT'
        },
        authClaimSet = {
            'iss': '295998782231-fgj5s8cf41i4gv6bpm957eqac7ttih6m@developer.gserviceaccount.com', // Service account email
            'scope': 'https://www.googleapis.com/auth/analytics.readonly', // We MUST tell them we just want to read data
            'aud': 'https://accounts.google.com/o/oauth2/token'
        },
        SIGNATURE_ALGORITHM = 'RSA-SHA256',
        SIGNATURE_ENCODE_METHOD = 'base64',
        GA_KEY_PATH = '#######DIRECTORY TO YOUR .PEM KEY#######', //finds current directory then appends private key to the directory
        gaKey = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDQtgcth7Lnpp/T\n8Nkpn+tNbuehlpHsvp20bme48+CXD3sRY6slgE36vO8zof3mp6FOO/Wkw4Nigjj+\nvPD/7rWVcv07T7SUCwXYouV4J/czNQ/sTK6eZ98jjcbUTqnWLL20AkfCGtLoIQAa\nb9CxZI1X1I3zT0UABPkgTts/AeIabNNogzNE0ER8qcAPUXlYbdgiwcVohqcZxp8A\nX2nhmnGjwXiNdJcOzT2W6H29IVoK3wrVOacyyUUU1xbC4OutQBOwuCOBmlwjdW5u\nBnLHXggATCJCseYRRjTOIDeefmmZHSUUjXlwz6/i+ytCKXit1UkoMbKPa8FhfKCB\nG6I9KSjdAgMBAAECggEAJBt5vmy9jMoM2JPQXh0mjizjsdbkw/puOirnkt3OOxQY\njHebwk8iLoDFOT+LN35Er847vxd8AWzaA2gYoY5gp8xO9xXg/cOybToxTMpNP/Ss\nHotdolYCCpqajVxWkZEH+L50P6Z4WmRrKieyCR6GPW2uaSuLmmdB2k8KKypePYfK\nSAsRF6wmWGxA6rKW/cZh3V68OdAU4w8idbDiafHEHLcXeA6l+VXkppiqrBxdFRyA\numHwl7hI8DS3wtFiwA+ytgWK24dozRlF/bZLiI6QFg5l9XZQLZmCpWeE0HIGJBls\n6yViLHh0qYNYsorV6PX13D2l1Q/R8ryrFoefrj9TwQKBgQDotWfXMtX8kJya6xzW\nUCZZzxAZo9bQlE5kCuJ+X1A1VjxIhRxbNP7o0DUfs9IjVB596BewdppEtspoNGgW\n/1a7q7qUekMOVmdaYQ5mI47GaZsu1rSehY5GHS4uIP8OJG9UrkcbZo8JdQ1cbQM+\nR8QQQEW4bOkJ7ZAWPpv4OQzAWQKBgQDlmb4sXee4fNvwGsdcn3tjU/8gN9UfYWNV\nRHBRjAo+3a6jbiC76z1resKxPqmjVJaaOlZqTUGL5OYSl3pJG9xdtzkOk1MNNrkF\nfNGL90JZX3PC+HgphIuggJPgwjV3OZ9Ln1j83RSYefDUKevUKnY4z6NRAKZp53gU\n9SweB5C8JQKBgQDduPJepW4jvfmo1bldLXLNATBa7bNget4SDhjtxYzbtPWtNz7k\nXCNA2hizwxbGWIDRABGKLgcgz3UdQkmnF9Sg7afRjohTodnJ0E3y3ZBM1hRo1WO0\n4pXDkkwM4Z2C8Q4uhfr0TYyduyxm0utTLPfPcB298e88aWBvAWqEYH8YyQKBgE2i\nfrthxUiMb5HwfBjFlGMxs8KhHl9N/tiGG7R3Nb+sFbENO+RO1qXRDKQCHDouD/52\nW2H2XYOAEouWzLKLySenHJPhHOQK7OT+H5zELpspu2rhuT/QoaXT1CzbfliiE0ru\nxpg56QzlrpkO078Z3H+5Ne/d2GdW7TOo8xH0XOxBAoGAejRMSe3XO59ed9Xuiy5M\nav9uCcnSOyDRLha7Ib5rt4yNLCNKCEa7sTcSMGmfrJaQcsSK4onz44SfoQj/jYLJ\nTDyQXCocyZLfcluJ8sn7Py1QiTqJYtHrm2IhlzhobvoJGePZjfxhYqSbkt0LOPcR\nXxKjloUGVaWSQxqtkbaly7w\u003d\n-----END PRIVATE KEY-----\n";

    var datemostcurrent = 4575744000000;
    var dateold = 4575741000000;

    function urlEscape(source) {
        return source.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '');
    }

    function base64Encode(obj) {
        var encoded = new Buffer(JSON.stringify(obj), 'utf8').toString('base64');
        return urlEscape(encoded);
    }

    function readPrivateKey() {
        if (!gaKey) {
            gaKey = fs.readFileSync(GA_KEY_PATH, 'utf8');
        }
        return gaKey;
    }

    var authorize = function(callback) {

        var self = this,
            now = parseInt(Date.now() / 1000, 10), // Google wants us to use seconds
            cipher,
            signatureInput,
            signatureKey = readPrivateKey(),
            signature,
            jwt;

        // Setup time values
        authClaimSet.iat = now;
        authClaimSet.exp = now + 60; // Token valid for one minute

        // Setup JWT source
        signatureInput = base64Encode(authHeader) + '.' + base64Encode(authClaimSet);

        // Generate JWT
        cipher = crypto.createSign('RSA-SHA256');
        cipher.update(signatureInput);
        signature = cipher.sign(signatureKey, 'base64');
        jwt = signatureInput + '.' + urlEscape(signature);

        // Send request to authorize this application
        request({
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            uri: 'https://accounts.google.com/o/oauth2/token',
            body: 'grant_type=' + escape('urn:ietf:params:oauth:grant-type:jwt-bearer') +
                '&assertion=' + jwt
        }, function(error, response, body) {
            if (error) {
                console.log(error);
                callback(new Error(error));
            } else {
                var gaResult = JSON.parse(body);
                if (gaResult.error) {
                    callback(new Error(gaResult.error));
                } else {
                    callback(null, gaResult.access_token);
                    console.log(gaResult);
                    console.log("Authorized");
                    //###########IF IT REACHES THIS STAGE THE ACCOUNT HAS BEEN AUTHORIZED##############
                }
            }
        });

    };



    var request = require('request'),
        qs = require('querystring');

    authorize(function(err, token) {
        if (!err) {
            executeQueryFoodRanking(token);
            executeQueryFoodRankingOld(token);
            executeQueryLocation(token);
            executeDailyUserCountByMobile(token);
            executeUserLocations(token);
        }
        else
        {
            console.error('ERROR ',err);
        }
    });


 function getQueryFoodRanking()
 {
    return   {
                'ids': 'ga:93028403',
                'dimensions': 'ga:screenName',
                'metrics': 'ga:sessions',
                'sort': '-ga:sessions',
                'start-date': '1daysAgo',
                'end-date': 'yesterday',
                'filters': 'ga:screenName=~/nutrition*'
            };
 }

 function getQueryFoodRankingOldDate()
 {
    return   {
                'ids': 'ga:93028403',
                'dimensions': 'ga:screenName',
                'metrics': 'ga:sessions',
                'sort': '-ga:sessions',
                'start-date': '30daysAgo',
                'end-date': '29daysAgo',
                'filters': 'ga:screenName=~/nutrition*'
            };
 }

function getLocationServices()
{
    return {

        'ids': 'ga:93028403',
        'dimensions': 'ga:eventCategory,ga:eventAction,ga:eventLabel',
        'metrics': 'ga:users',
        'sort': '-ga:users',
        'start-date': '30daysAgo',
        'end-date': 'yesterday',
        'filters': 'ga:eventLabel==Enter an address,ga:eventLabel==Current Location Notification - OK',
        'max-results' :10
    }
}

// This grabs food rankings from yesterday.
function executeQueryFoodRanking(token)
{

    console.log('token ',token);
    request({
    method: 'GET',
    headers: {
        'Authorization': 'Bearer ' + token
    },
     uri: 'https://www.googleapis.com/analytics/v3/data/ga?' + qs.stringify(getQueryFoodRanking())
    }, function(error, resp, body) {
               
        var data = JSON.parse(body);
       // console.log('data ',data);
      /* fs.writeFile(__dirname + 'output.txt',body,function(err){
         if(err) console.log('err writing file ',err);
       })*/
        var lambda = new Lambda();
        var coll = lambda.topCampaigns(data.rows);
        db.insert('top_campaigns',coll,'Google', datemostcurrent, function(err,data){
            if(err)
            {
                console.log('ERR ',err);
            }
            else
            {
                console.log('Success ',data);
            }
        })
    });
}

// This grabs the food rankings from 30 days ago.
function executeQueryFoodRankingOld(token)
{

    console.log('token ',token);
    request({
    method: 'GET',
    headers: {
        'Authorization': 'Bearer ' + token
    },
     uri: 'https://www.googleapis.com/analytics/v3/data/ga?' + qs.stringify(getQueryFoodRankingOldDate())
    }, function(error, resp, body) {
               
        var data = JSON.parse(body);
       // console.log('data ',data);
      /* fs.writeFile(__dirname + 'output.txt',body,function(err){
         if(err) console.log('err writing file ',err);
       })*/
        var lambda = new Lambda();
        var coll = lambda.topCampaigns(data.rows);

        // Here we use dateold instead of datemostcurrent.
        db.insert('top_campaigns',coll,'Google', dateold, function(err,data){
            if(err)
            {
                console.log('ERR ',err);
            }
            else
            {
                console.log('Success ',data);
            }
        })
    });
}


function executeQueryLocation(token)
{
    console.log('Executing Query by Location');
    request({
    method: 'GET',
    headers: {
        'Authorization': 'Bearer ' + token
    },
     uri : "https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A93028403&start-date=30daysAgo&end-date=yesterday&metrics=ga%3Ausers&dimensions=ga%3AeventCategory%2Cga%3AeventAction%2Cga%3AeventLabel&sort=-ga%3Ausers&filters=ga%3AeventLabel%3D%3DEnter%20an%20address%2Cga%3AeventLabel%3D%3DCurrent%20Location%20Notification%20-%20OK&max-results=1000"
     //uri: 'https://www.googleapis.com/analytics/v3/data/ga?' + qs.stringify(getLocationServices())
    }, function(error, resp, body) {
               
        var data = JSON.parse(body);
       //console.log('data ',data);
      /* fs.writeFile(__dirname + 'location.txt',body,function(err){
         if(err) console.log('err writing file ',err);
       });*/
        var lambda = new Lambda();
        var coll = lambda.locations(data.rows);
        console.log('coll ',coll);
        db.insert('restaurant_search',coll,'Google', datemostcurrent, function(err,data){
            if(err)
            {
                console.log('ERR ',err);
            }
            else
            {
                console.log('Success ',data);
            }
        });
    });    
}


function executeDailyUserCountByMobile(token)
{

    console.log('Executing Query Daily User Count Mobile');
    //need to get previous weeks worth of data;
   var begin_week =  moment().startOf('week').format('YYYY-MM-DD');
   var last_week_start = moment(begin_week).subtract(6,'days').format('YYYY-MM-DD');
    request({
    method: 'GET',
    headers: {
        'Authorization': 'Bearer ' + token
    },
     uri : "https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A93028403&start-date="+last_week_start+"&end-date="+begin_week+"&metrics=ga%3Ausers&dimensions=ga%3AoperatingSystem%2Cga%3Adate&filters=ga%3AoperatingSystem%3D%3DiOS%2Cga%3AoperatingSystem%3D%3DAndroid"
    }, function(error, resp, body) {
               
        var data = JSON.parse(body);
        //console.log('data rows ',data.rows);
     
        var lambda = new Lambda();
        var coll = lambda.dailyUserCount(data.rows);
        console.log('coll ',coll);
        db.insert('daily_user_count',coll,'Google', datemostcurrent, function(err,data){
            if(err)
            {
                console.log('ERR ',err);
            }
            else
            {
                console.log('Success ',data);
            }
        }); 
    });    
}

function executeUserLocations(token)
{
    console.log('Executing User Locations');
    request({
    method: 'GET',
    headers: {
        'Authorization': 'Bearer ' + token
    },
     uri :"https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A93028403&start-date=30daysAgo&end-date=yesterday&metrics=ga%3Asessions&dimensions=ga%3Aregion%2Cga%3Alatitude%2Cga%3Alongitude&sort=-ga%3Asessions&filters=ga%3Acountry%3D%3DUnited%20States"
    }, function(error, resp, body) {
               
        var data = JSON.parse(body);

       /*fs.writeFile(__dirname + '/user_locations.txt',body,function(err){
         if(err) console.log('err writing file ',err);
       });*/
        var lambda = new Lambda();
        var coll = lambda.usersByLocation(data.rows);
        //console.log('users by location ',coll);
        db.insert('users_by_location',coll,'Google', datemostcurrent, function(err,data){
           if(err)
            {
                console.log('ERR ',err);
            }
            else
            {
                console.log('Success ',data);
            }
        });
    });       
    }

};
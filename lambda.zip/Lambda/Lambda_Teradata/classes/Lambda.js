//Helper lambda function for parsing teradata and google analytics;
'use strict'
var _ = require('underscore');
var moment = require('moment');

//set local day
moment.locale('en', {
    weekdays : [
        "S", "M", "T", "W", "TH", "F", "S"
    ]
});
var Lamda = function(json)
{
	if(!json) throw Error('No JSON file!');
	this.data = json;
}

/* OVERVIEW */
Lamda.prototype.dailyDownloads = function() {
	var downloads = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('downloads'))
		{
			return obj;
		}
	});
	return formatDailyDownloads(downloads);
};

Lamda.prototype.appUpdates = function()
{
	var updates = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('appupdates'))
		{
			return obj;
		}
	});
	console.log(updates.appupdates);
	return updates.appupdates;
}
Lamda.prototype.appRatings = function() {
	var ratings = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('appratings'))
		{
			return obj;
		}
	});
	return formatAppRatings(ratings);
};
Lamda.prototype.campaigns = function()
{
	var campaigns = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('campaigns'))
		{
			return obj;
		}
	});
	return formatCampaigns(campaigns);
}

Lamda.prototype.totalDownloads = function()
{
	var downloads = _.find(this.data,function(obj){
	if(obj.hasOwnProperty('downloads'))
	{
		return obj;
	}
	});
	return formatTotalDownloads(downloads);
}

Lamda.prototype.lastWeekDownloads = function()
{
	var downloads = _.find(this.data,function(obj){
	if(obj.hasOwnProperty('downloads'))
	{
		return obj;
	}
	});
	return formatLastWeekDownloads(downloads);	
}

function formatDailyDownloads(a_Downloads)
{
	var formatted_downloads = [];
	var downloads = a_Downloads.downloads;
	for(var i = 0 ; i < downloads.length; i++)
	{
		
		var obj_with_same_date = _.where(downloads,{CAL_DT : downloads[i].CAL_DT});
		

		if(obj_with_same_date.length > 0 )
		{
			//check to see if the date already exist in our formatted downloads array
			var timestamp = moment(obj_with_same_date[0].CAL_DT).unix() * 1000;
			var exists = _.findWhere(formatted_downloads,{timestamp : timestamp});
			if(!exists)
			{
				//format then push otherwise just continue
				var tmp = {
					timestamp : timestamp
				}
				tmp.count = {}; 
				//object mappings convert to lowercase
				tmp.count[obj_with_same_date[0].DVCE_OPRG_SYS_DS.toLowerCase()] = obj_with_same_date[0].APLC_DWLD_QT;
				tmp.count[obj_with_same_date[1].DVCE_OPRG_SYS_DS.toLowerCase()] = obj_with_same_date[1].APLC_DWLD_QT;
				formatted_downloads.push(tmp);

			}
		}

	}
	//console.log('formatted downloads ',formatted_downloads);
	return formatted_downloads;
}

function formatCampaigns(a_campaigns)
{
	
	var transformation = _.map(a_campaigns.campaigns,function(campaign){
		var tmp = {
			start_timestamp : campaign.DIGL_OFFR_STRT_TS,
			end_timestamp   : campaign.DIGL_OFFR_END_TS,
			label           : campaign.DIGL_OFFR_NA
		}
		return tmp;
	});
	
	return transformation;
}

function formatTotalDownloads(a_Downloads)
{
		
	var downloads = formatDailyDownloads(a_Downloads);
	
	var total = 0;
	downloads.forEach(function(download){
		total += download.count.android + download.count.ios;
	});
	
	return {total_downloads : total};
}

function formatLastWeekDownloads(a_Downloads)
{
	var today =  moment().valueOf(); //new Date();
	var lastweek = moment(today).subtract(7,'days').valueOf(); // new Date();
	//lastweek.setDate(today.getDate() - 7);
	console.log('today timestamp ',today);
	console.log('last week timestamp ',lastweek);
	var today_timestamp = today;    //moment(today).valueOf();//today.getTime();
	var lastweek_timestamp =  lastweek; // moment(lastweek).valueOf(); //lastweek.getTime();
	//console.log(today_timestamp);
	//console.log(lastweek_timestamp);
	var downloads = formatDailyDownloads(a_Downloads);
	console.log('last week donwloads after formatting ',downloads);
	var a_lastweek_downloads = [];
	var sorted_downloads = _.sortBy(downloads, function(download){
		return download.timestamp;
	});
	console.log('sorted downloads ',sorted_downloads);
	var removed = sorted_downloads.splice(-7,7); //get last seven items from array
	console.log('removed ',removed);
	removed.forEach(function(remove){
		
			
			var day_of_week = moment(remove.timestamp).day();
			remove.label = moment.weekdays(day_of_week);
			delete remove.timestamp;

			a_lastweek_downloads.push(remove);
		
	});
	
	console.log('last week downloads after formatting ',a_lastweek_downloads);
	return a_lastweek_downloads;


}
function formatAppRatings(ratings)
{
	return ratings.appratings;
}



/***********************Users********************************************/

Lamda.prototype.dailyUserCount = function()
{

}

/**********************End Users******************************************/


/**********************Offers**********************************************/
Lamda.prototype.averageCheckWithOffer = function()
{
	var checks = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('check'))
		{
			return obj;
		}
	});
	return formatAverageCheckWithOffer(checks.check,'MobileAvgCheck'); //second param is the key with and without offer	
}


Lamda.prototype.averageCheckWithoutOffer = function()
{
	var checks = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('check'))
		{
			return obj;
		}
	});
	return formatAverageCheckWithOffer(checks.check,'NonMobileAvgCheck'); //second param is the key with and without offer	
}

Lamda.prototype.offersLastWeek = function()
{
	var offers_last_week = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('offersRedeemed'))
		{
			return obj;
		}
	});

	return formatOffersRedeemedLastWeek(offers_last_week.offersRedeemed);
}

Lamda.prototype.offersThisWeek = function()
{
	var offers_this_week = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('offersRedeemed'))
		{
			return obj;
		}
	});

	return formatOffersRedeemed(offers_this_week.offersRedeemed);
}
Lamda.prototype.realTimeLocations = function()
{
	var offers_by_lat_long  = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('offersbylatlong'))
		{
			return obj;
		}

	});
	return formatOffersByLatLng(offers_by_lat_long.offersbylatlong);
}

Lamda.prototype.offersGraph = function() {
	// body...
	var offersGraph = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('offersgraph'))
		{
			return obj;
		}
	});
	
	return formatOffersGraph(offersGraph.offersgraph);
};

function formatOffersGraph(offers)
{
	var formattedOffers = [];
	offers.forEach(function(offer){
		var tmp = {

			count : parseInt(offer.OfferCount),
			timestamp : moment(offer.POS_BUSN_DT).valueOf()

		}
		formattedOffers.push(tmp);
	});
	console.log('formatted Offers ',formattedOffers);
	return formattedOffers;
}
function formatAverageCheckWithOffer(checks,key)
{
	
	//console.log('checks ',checks);
	//we need to extract all checks with MobileAvgCheck with the same date and return the avg check with offer.
	var check_with_same_date = []; //an array of object sorted by unique date


	checks.forEach(function(check){
		var date_timestamp = moment(check.POS_BUSN_DT).valueOf();
		//console.log(date_timestamp);
		var exists = _.findWhere(check_with_same_date,{timestamp : date_timestamp});
		if(!exists)
		{
			//create new object and add it to array
			var tmp = {
				timestamp  : date_timestamp,
				values : [check[key]]

			}
			check_with_same_date.push(tmp);
		}
		else
		{
			exists.values.push(check[key]);
		}


	});
	console.log(check_with_same_date ,'lenght is ',check_with_same_date.length);
	var check_avg = calculateOfferAvg(check_with_same_date);
	console.log('sum of checks by date with offer ',check_avg);
	return check_avg;
}

function calculateOfferAvg(checks)
{	
	var offer_avg_by_date = _.map(checks,function(check){
		check.sum =  check.values.reduce(function(prev,cur){
			return prev + cur;
		});
		return check;
	});


	//lets not calculate the avg and delete uneeded values
	var offer_avg_by_date = _.map(offer_avg_by_date,function(check){
		check.value = check.sum / check.values.length; //lets round
		delete check.sum;
		delete check.values;
		check.value = parseFloat(check.value.toFixed(2));
		return check;

	});
	return offer_avg_by_date;
}

function formatOffersByLatLng(offers)
{
	//console.log(offers);
	var offers = _.map(offers,function(offer){
		
	 	var tmp = {
	 		longitude : offer.REST_LON_NU,
	 		latitude  : offer.REST_LAT_NU,
	 		value     : offer.OfferCount
	 	}
	 	return tmp;
	});
	//console.log(offers);
	return offers;
}

function formatOffersRedeemed(offersRedeemed)
{
	//console.log('start of week ' , moment().startOf('isoweek'));
	//console.log('start of week timestamp ',moment().startOf('isoweek').valueOf());
	var beginning_of_week_timestamp = moment().startOf('isoweek').valueOf();
	var todays_timestamp = moment().valueOf();

	var offers_redeemed = [];
	offersRedeemed.forEach(function(offer){
		var offer_timestamp = moment(offer.POS_BUSN_DT).valueOf();
		if(offer_timestamp >= beginning_of_week_timestamp && offer_timestamp <= todays_timestamp)
		{
			offers_redeemed.push(offer);
		}
	});

	//lets not map this out to the new structure
	var new_offer_mapping = _.map(offers_redeemed,function(offer){

		var day_of_week = moment(offer.POS_BUSN_DT).day(); 
		var tmp = {
			count : offer.OfferCount,
			label : moment.weekdays(day_of_week)
		}
		return tmp;
	});

	//console.log('offers_redeemed array ',new_offer_mapping);
	return new_offer_mapping;

}

function formatOffersRedeemedLastWeek(offersRedeemed)
{
	var beginning_of_week_timestamp = moment().startOf('isoweek').valueOf();
	//now we have beginning of week we need to subtract 7 days;
	var last_week_timestamp = moment(beginning_of_week_timestamp).subtract(7,'days').valueOf();

	var offers_redeemed = [];
	offersRedeemed.forEach(function(offer){
		var offer_timestamp = moment(offer.POS_BUSN_DT).valueOf();
		if(offer_timestamp >= last_week_timestamp && offer_timestamp < beginning_of_week_timestamp)
		{
			offers_redeemed.push(offer);
		}
	});

	//lets now map this out to the new structure

	var new_offer_mapping = _.map(offers_redeemed,function(offer){

		var day_of_week = moment(offer.POS_BUSN_DT).day(); 
		var tmp = {
			count : offer.OfferCount,
			label : moment.weekdays(day_of_week)
		}
		return tmp;
	});

	return new_offer_mapping;



}

/*************************End Offers**************************************/

/*************************Offer Impact ***********************************/


Lamda.prototype.redemptionsByDayPart = function() {
	var downloads = _.find(this.data,function(obj){
		if(obj.hasOwnProperty('downloads'))
		{
			return obj;
		}
	});
	return formatDailyDownloads(downloads);
};

/*************************End Offer Impact *******************************/

module.exports = Lamda;

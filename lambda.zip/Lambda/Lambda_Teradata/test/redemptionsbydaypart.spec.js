'use strict'
const Database = require('../classes/Database');
const chai = require('chai');

let dailyDownloads = lambda.redemptionsByDayPart();


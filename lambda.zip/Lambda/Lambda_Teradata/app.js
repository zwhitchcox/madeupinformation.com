
exports.handler = function(event,context)
{
	var AWS = require('aws-sdk');
	var Database = require('./classes/Database');
	var Lambda = require('./classes/Lambda');
	var util = require('util');
	var async = require('async');
	var s3 = new AWS.S3();
	var lambda;
	// Read options from the event.
	console.log("Reading options from event:\n", util.inspect(event, {depth: 5}));
	var srcBucket = event.Records[0].s3.bucket.name;
	var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));
	// Object key may have spaces or unicode non-ASCII characters.
	console.log("Src Bucket ",srcBucket);
	console.log('Src Key ',srcKey);
	var db = new Database('AKIAIES7HWWZXH5XUKCQ','+OiIOepShMFwuDuwiAoRvMWKWFCDK9sR88y2+yte','us-east-1');
	//context.done();
	//lets read in our tera data file

	s3.getObject({
		Bucket : srcBucket,
		Key    : srcKey,
		ResponseContentType : 'application/json'
	},function(err,data){
		if(err) console.log(err,err.stack);
		else
			var sObject = data.Body.toString();
			var object = JSON.parse(sObject);
			//console.log('got object ',object);
			//lets now parse our data
			lambda = new Lambda(object);

			//we need to now insert our data. Our async lib will handle kicking off our inserts in parallel
			async.parallel([
				function()
				{
					var dailyDownloads = lambda.dailyDownloads();
					
					console.log('inserting daily downloads ',dailyDownloads);
					db.insert('daily_downloads',dailyDownloads,'Mulesoft',callBack);
				},
				function()
				{
					var appUpdates = lambda.appUpdates();
					console.log('appUpdates ',appUpdates);
					db.insert('app_updates',appUpdates,'Mulesoft',callBack);
				},
				function()
				{
					
					var appRatings = lambda.appRatings();
					console.log('appRatings ',appRatings);
					db.insert('app_ratings',appRatings,'Mulesoft',callBack);
				},
				function()
				{
					
					var campaigns  = lambda.campaigns();
					console.log('campaigns ',campaigns);
					db.insert('campaigns',campaigns,'Mulesoft',callBack);
				},
				function()
				{
					var totalDownloads = lambda.totalDownloads();
					console.log('totalDownloads ',totalDownloads);
					db.insert('total_downloads',totalDownloads,'Mulesoft',callBack);
				},
				function()
				{
					var lastWeekDownloads = lambda.lastWeekDownloads();
					console.log('lastWeekDownloads ',lastWeekDownloads);
					db.insert('lastweek_downloads',lastWeekDownloads,'Mulesoft',callBack);
				},
				function(){
					//offers redeemed 
					var offersGraph = lambda.offersGraph();
					console.log('offersGraph ',offersGraph);
					db.insert('offers_graph',offersGraph,'Mulesoft',callBack);
				},
				function(){
					//average check with offer 
					var average_check_with_offer = lambda.averageCheckWithOffer();
					//console.log('offersGraph ',offersGraph);
					db.insert('average_check_with_offer',average_check_with_offer,'Mulesoft',callBack);
				},
				function(){
					//average check without ouffer 
					var average_check_without_offer = lambda.averageCheckWithoutOffer();
					//console.log('offersGraph ',offersGraph);
					db.insert('average_check_without_offer',average_check_without_offer,'Mulesoft',callBack);
				},
				function()
				{
					
					var offersLastWeek = lambda.offersLastWeek();
					console.log('offersLastWeek ',offersLastWeek);
					db.insert('offers_last_week',offersLastWeek,'Mulesoft',callBack);
				},
				function()
				{
					
					var offersThisWeek = lambda.offersThisWeek();
					console.log('offersThisweek ',offersThisWeek);
					db.insert('offers_this_week',offersThisWeek,'Mulesoft',callBack);
				},
				function()
				{
					
					var realTimeLocations = lambda.realTimeLocations();
					console.log('realTimeLocations ',realTimeLocations );

					db.insert('realtime_locations',realTimeLocations,'Mulesoft',callBack);
				}


				],function(err,data){
					if(err)
					{
						context.fail(err);
					}
					else
					{
						context.succeed(data);
					}
			})
			//context.succeed(object);
	});



function callBack(err,data)
{
	console.log('callback called');
	if(err) return err;
    if(data) return data;	
}




}
